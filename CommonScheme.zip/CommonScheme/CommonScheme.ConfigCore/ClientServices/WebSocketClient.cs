﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonScheme.ConfigCore.ClientServices
{
    public class WebSocketClient: ClientServiceBase
    {
    }
}
