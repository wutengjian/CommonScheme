﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonScheme.ConfigCore.OAServices
{
    public class ProductionOA: OAServiceBase
    {
        public ProductionOA() : base("ProductionOA") { }
    }
}
