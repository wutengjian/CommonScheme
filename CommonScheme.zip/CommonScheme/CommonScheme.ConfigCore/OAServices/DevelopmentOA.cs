﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonScheme.ConfigCore.OAServices
{
    public class DevelopmentOA : OAServiceBase
    {
        public DevelopmentOA():base("DevelopmentOA") {}
    }
}
