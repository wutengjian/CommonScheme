﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonScheme.Net
{
    class DBElasticSearch
    {
    }
}
