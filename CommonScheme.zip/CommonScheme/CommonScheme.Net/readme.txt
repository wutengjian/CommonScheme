﻿ElasticSearch主要参考
https://www.cnblogs.com/huhangfei/p/7085328.html

redis主要参考
https://www.cnblogs.com/JulianHuang/p/12687090.html 哨兵模式
https://www.pianshen.com/article/2037700174/  redisCluster的conf文件配置
https://www.cnblogs.com/zhoujinyi/p/11606935.html  redisCluster集群配置
